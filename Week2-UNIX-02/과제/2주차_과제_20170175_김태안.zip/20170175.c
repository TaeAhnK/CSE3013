#include "20170175.h"

int main() {
  int testNum;
  int i = 0;
  int* Numbers;
  scanf("%d", &testNum);
  while(i<testNum){
    Numbers = NCounter();
    i++;
  }
  return 0;
}
