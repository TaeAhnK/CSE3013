#include <stdio.h>

int* NCounter (void);
void ResultPrinter(int* Numbers);
