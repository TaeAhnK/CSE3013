#include "20170175.h"

void ResultPrinter(int* Numbers){
  int i;
  for(i=0; i<10; i++){
    printf("%d ", Numbers[i]);
  }
  printf("\n");
}
